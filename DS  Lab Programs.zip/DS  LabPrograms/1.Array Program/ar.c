#include<stdio.h>
int a[100];
int i;
int n;
int ele;
int pos;
int x;
void create()
{
 printf("Enter the number of elements \n");
 scanf("%d",&n);
 printf("Enter the array elements \n");
 for(i=0;i<n;i++)
{
   scanf("%d",&a[i]);
}
 printf("Array is created\n");
}
 void display()
{
  printf("Array elements are: \n");
  for(i=0;i<n;i++)
{
    printf("%d \t",a[i]);
}
} 
void insert()
{
 printf("Enter the position and the element to be inserted \n");
 scanf("%d %d", &pos,&ele);
 pos=pos-1;
 if(pos<n)
 {
  for(i=n-1;i>=pos;i--)
   {
    a[i+1]=a[i];
   }
  a[pos]=ele; n=n+1;
  printf("Element Inserted successfully\n");
 }
  else 
       if(pos>n)
        {
         printf("Invalid Position \n");
        }
        else
        {
          a[n]==ele;
          printf("Element Inserted successfully\n");
          n=n+1;
        }
}
 void delete()
{
 printf("Enter the position where the element should be deleted\n");
 scanf("%d",&pos);
 pos=pos-1;
 if(pos<n)
  {
   ele=a[pos];
   for(i=pos;i<n;i++)
    {
      a[i]=a[i+1];
    }
   n=n-1;
   printf("Element %d is removed from %d",ele,pos+1);
   }
 else 
     if(pos>n)
      {
        printf("Invalid position \n");
       }
      else
       {
        ele=a[pos];
        n=n-1;
        printf("Element %d is removed from %d",ele,pos+1);
        }
}
 void main()
{
  while(1)
  {
   printf("Enter 1-Create an array,Enter 2-Display an array,Enter 3-Insert an element at a  given position, Enter 4-Delete an element from a position, Enter 5-Exit the program\n");
   scanf("%d",&x);
   switch(x)
   {
   case 1: create();
           break;
   case 2: display();
           break;
   case 3: insert();
           break;
   case 4: delete();
           break;
   case 5: printf("Thank you \n");
           exit(0);
   default:printf("Invalid Choice \n");
  }
}
}

