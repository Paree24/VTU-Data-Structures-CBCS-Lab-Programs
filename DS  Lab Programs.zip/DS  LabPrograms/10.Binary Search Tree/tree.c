#include<stdio.h>
#include<stdlib.h>

struct treelist
{
int data;
struct treelist *left, *right;
};

typedef struct treelist *TNODE;
TNODE tree;

TNODE maketree(int x)
{
 TNODE temp;
 temp=(struct treelist *)malloc(sizeof(struct treelist));
 temp->data=x;
 temp->left=NULL;
 temp->right=NULL;
 return temp;
}

void create()
{
 TNODE p,q; int x;
 printf("Enter first number \n");
 scanf("%d",&x);
 tree= maketree(x);
 while(1)
 {
   printf("Enter next number, 0 to stop \n");
   scanf("%d",&x);
   if(x==0)
   break;
   p=q=tree;
   while(q!=NULL)
   {
     p=q;
     if(x<p->data)
      q=p->left;
     else
      q=p->right;
   }
   if(x<p->data)
     p->left= maketree(x);
   else
     p->right= maketree(x);
  }
}

void intrav(TNODE tree)
{
 if(tree!=NULL)
 {
  intrav(tree->left);
  printf("%d\t",tree->data);
  intrav(tree->right);
  }
}

void pretrav(TNODE tree)
{
 if(tree!=NULL)
 {
  printf("%d\t",tree->data);
  pretrav(tree->left);
  pretrav(tree->right);
  }
}

void posttrav(TNODE tree)
{
 if(tree!=NULL)
 {
  posttrav(tree->left);
  posttrav(tree->right);
  printf("%d\t",tree->data);
  }
}

TNODE search(TNODE tree, int key)
{
 if(tree==NULL)
  return NULL;
 if(key==tree->data)
  return tree;
 if(key<tree->data)
   search(tree->left, key);
 else 
   search(tree->right, key);
}

void main()
{
 int ch, key;
 TNODE p;
 while(1)
 {
   printf("\nEnter 1: Create a BST\t2:Inorder Traversal\t3:Preorder Traversal\t4:Postorder Traversal\t5:Search an element\t6:Exit\n");
   printf("Enter Option\n");
   scanf("%d",&ch);
   switch(ch)
   {
    case 1: create();break;
    case 2: intrav(tree); break;
    case 3: pretrav(tree); break;
    case 4: posttrav(tree); break;
    case 5: printf("\t Enter element to be searched \n");
            scanf("%d",&key);
            p=search(tree,key);
            if(p)
             printf("\tElement Found\n");
            else
             printf("\tElement not Found\n");
            break;
    case 6: printf("\t ***End of Program*** \n"); exit(0);
    default: printf("Invalid Choice\n");           
   }
  }
}
   
   
   
   
   
   
   





