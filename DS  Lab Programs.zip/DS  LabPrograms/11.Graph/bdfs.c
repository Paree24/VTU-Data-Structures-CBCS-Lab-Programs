#include<stdio.h>
int n, a[20][20],w, r[10]={0};
void bfs(int u)
{
 int r=-1,f=0,v;
  int s[10]={0}, q[10];
 s[u]=1;
 q[++r]=u;
 printf("%d\t",u);
 while(f<=r)
 {
   u=q[f++];
   for(v=0;v<n;v++)
   {
    if(a[u][v]==1)
    {
       if(s[v]!=1)
       {
            s[v]=1;
            q[++r]=v;
             printf("%d\t",v);
             }
            }
           }
          }
         }
 void dfs(int u)
 {
  r[u]=1;
  printf("%d\t",u);
  for(w=0;w<n;w++)
  {
     if((a[u][w]==1)&&(r[w]!=1))
     {
           dfs(w);
        }
       }
      return;
     }
void main()
{
 int u,i,j;
 printf("\tEnter the no. of nodes \n");
 scanf("%d",&n);
 printf("\tEnter the matrix \n");
 for(i=0;i<n;i++)
 {
   for(j=0;j<n;j++)
   {
      scanf("%d",&a[i][j]);
      }
     }
   printf("\tEnter the source node\n");
   scanf("%d",&u);
   printf("\tUsing bfs \t");
   bfs(u);
   printf("\tUsing dfs \t");
   dfs(u);
   printf("\n");
   }
