#include<stdio.h>
#define sz 5
int read();
int genkey(int num);
void linearprob(int key, int num, int ht[]);
void display(int a[]);
typedef struct employee
{
 char name[10];
 int index;
} emp;
emp st[100];
void main()
{
 int ht[sz]; int i,n ,key;
 for(i=0;i<sz;i++)
 { 
   ht[i]=-1;
 }
 n=read();
 for(i=0;i<n;i++)
 {
  key=genkey(st[i].index);
  linearprob(key,st[i].index,ht);
 }
 display(ht);
}
int read()
{
 FILE *fp; int i=0;
 fp=fopen("abc.txt","r");
 while(!feof(fp))
 {
   fscanf(fp, "%d", &st[i++].index);
 }
 return i-1;
}
int genkey(int num)
{
 int key,m=1001;
 key=num%m;
 return key;
}
void display(int a[])
{
  int i;
  for(i=0;i<sz;i++)
 if(a[i]!=-1)
 {    
 printf("Index value is:%d Element is: %d \n",i, a[i]);
 }
}
void linearprob(int key, int num, int ht[])
{
  int i,cnt=0;
  if(ht[key]==-1)
  { ht[key]=num;
    return;
  }
  for(i=0;i<sz;i++)
  {
   if(ht[i]==-1)
   {
     ht[i]=num;
     return;
   }
   if(ht[i]!=-1)
    cnt++;
  }
  if(cnt==sz)
  {
   printf("\t<<<Exhausted>>> \n");
   return;
  }
}
