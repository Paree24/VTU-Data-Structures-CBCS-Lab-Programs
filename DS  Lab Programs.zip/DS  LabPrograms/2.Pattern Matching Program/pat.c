#include<stdio.h>
#include<stdlib.h>
int patlen=0; char str[100], pat[100], rep[100];
void create()
{
 int i=0;
 printf("Enter main string \n");
 gets(str);
 printf("Enter pattern string \n");
 gets(pat);
 printf("Enter replacement string \n");
 gets(rep);
 while(pat[i]!='\0')
 {
   patlen=i+1; i++;
 }
}
void replace()
{
  int i,j,cn,k, flag=0;
  for(i=0;str[i]!='\0';)
  {
    j=0; cn=0;
    while((str[i]==pat[j])&&(pat[j]!='\0'))
    {
      i++; j++; cn++;
    }
    if(cn==patlen)
    {
     k=i-patlen;
     flag=1;
     int m=0;
     while(rep[m]!='\0')
     {
      str[k]=rep[m]; k++; m++;
     }
     }
     else i++;
   }
   if(flag==0)
      printf("Pattern not found \n");
   else
   {
     printf("Pattern found and replaced \n");
     puts(str);
     printf("\n");
   }
}
void main()
{
 create();
 replace();
}
     
