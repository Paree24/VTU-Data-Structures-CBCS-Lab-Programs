#include<stdio.h>
#include<stdlib.h>
#define MAX 5
int stk[MAX], top=-1; 
 void push(int ele)
 {
  if(top<MAX-1)
      stk[++top]=ele;
  else
      printf("Stack Overflow \n");
  }
 int pop()
  {
   int del;
   if(top!=-1)
      {del=stk[top--]; return(del);}
   else
   {
      return(0);
    }
   }
   void dis()
   {
    int i;
    if(top==-1)
     printf("Stack is empty\n");
    else
    { 
    printf("Stack is \n");
    for(i=0;i<top+1;i++)
    {
     printf("%d \t",stk[i]);
    }
    }
    }
   void pal()
   {
    int i=0,x, dig[100],n,c,num;
    printf("Enter the number \n");
    scanf("%d",&num);
    x=num;
    while(num>0)
    {
     dig[i]=num%10;
     push(dig[i]);
     num=num/10;
     i++;
     }
     n=i;c=0;
     for(i=0;i<n;i++)
      {
        if(dig[i]==pop())
          c++;
      }
      if(n==c)
         printf("%d is a palindrome",x);
      else
         printf("%d is not a palindrome",x);
    } 
  void main()
  {
  int o,x,ele;
  printf("Enter 1:Push\t2:Pop\t3:Palindrome\t4:Display\t5:Exit\n");
  while(1)
  {
    printf("\nEnter Option\n");
    scanf("%d",&o);
    switch(o)
    {
     case 1:printf("\nEnter element to be pushed\n");
            scanf("%d",&ele);
            push(ele);
            break;
     case 2:x=pop(); 
            if(x==0)
             printf("Stack underflow\n");
            else
            printf("\nDeleted element is %d",x);
            break;
     case 3:pal();break;
     case 4:dis();break;
     case 5:printf("Thank you\n");exit(0);
     default:printf("Invalid Choice \n");
     }
    }
  }
