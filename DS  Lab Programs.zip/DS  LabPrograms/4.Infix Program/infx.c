#include<stdio.h>
#include<string.h>
char stk[100],in[100],po[100];
int top=-1;
void push(char ch)
{
    stk[++top]=ch;
 }
 char pop()
 {
   return(stk[top--]);
  }
  int pr(char ch)
  {
    switch(ch)
     {
       case '#': return 0;
                      break;
       case '(' : return 1;
                      break;
       case '+':
       case '-':  return 2;
                       break;
       case '*':
       case '/':  return 3;
                      break;
       case '%':
       case '^':  return 4;
                        
        default: printf("Invalid operator\n");exit(0);
       }
    }
  void main()
  {
      int i=0;int t=0; char un; char ch; push('#');
      printf("Enter the Infix Expression \n");
      gets(in);
      while( (ch=in[i])!='\0')
       {
          if(ch=='(')
             push(ch);
          else 
          if(isalnum(ch))
             po[t++]=ch;
           else
              if(ch==')')
              {
              while(stk[top]!='(')
                 po[t++]=pop();
              un=pop();      
              }
              else{
                   while(pr(ch)<=pr(stk[top]))
                   
                      //while(stk[top]!= '#' || '(')
                          po[t++]=pop();
                          
                     push(ch);
                     }
                     
                     
        i++;
      }           
      while(stk[top]!='#')
       po[t++]=pop();
     po[t]='\0';  
     printf("Post Fix Expression is: \n");
     puts(po);
   }
