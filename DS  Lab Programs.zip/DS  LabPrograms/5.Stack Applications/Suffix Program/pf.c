#include<stdio.h>
#include<math.h>
#include<string.h>
int stk[50],top=-1;
void push(int x)
{
  stk[++top]=x;
}
 int pop()
 {
  return stk[top--];
 }
 main()
 {
  char post[50];
  int num, res,op1,op2,i=0;
  printf("Enter the postfix expression \n");
  gets(post);
  while(post[i]!= '\0')
  {
    if(isalnum(post[i]))
    {
      num=post[i]-48;
      push(num);
    }
    else
    {
     op2=pop();
     op1=pop();
     switch(post[i])
     {
      case '+' : res=op1+op2;
                 break;
      case '-' : res=op1-op2;
                 break;
      case '*' : res=op1*op2;
                 break;
      case '/' : res=op1/op2;
                 break;
      case '%' : res=op1%op2;
                 break;
      case '^' : res=pow(op1,op2);
                 break;
      default:printf("Invalid Operator \n");
              exit(0);
      }
      push(res);
     }
     i++;
   }
    printf("Result is %d \n", pop());
  }
