#include<stdio.h>
void tower(int n, char s, char t, char d)
{
  if(n==1)
  {
    printf("Moved %d from %c -> %c \n",n, s, d);
    return;
  }
  else{
       tower(n-1,s,d,t);
       printf("Moved %d from %c -> %c \n", n,s,d);
       tower(n-1,t,s,d );
 }}
 main()
 {
   int n;
   printf("Enter n \n");
   scanf("%d", &n);
   tower(n,'a','b','c');
  } 
