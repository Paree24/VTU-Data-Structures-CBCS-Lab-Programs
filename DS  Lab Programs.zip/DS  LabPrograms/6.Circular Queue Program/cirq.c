#include<stdio.h>
#include<stdlib.h>
#define MAX 5
int q[MAX],f=0,r=-1,count=0;
void insert();
void delete();
void display();
void main()
{
 int op;
 printf("Enter\n1.Insert\n2.Delete\n3.Display\n4.Exit\n");
 while(1)
 {
  printf("Enter your option\n");
  scanf("%d",&op);
  switch(op)
  {
   case 1:insert();break;
   case 2:delete();break;
   case 3:display();break;
   case 4:exit(0);break;
   default: printf("Invalid Option \n");
  }
 }
}
void insert()
{
 int ele;
 if(count<MAX)
 {  
  printf("Enter the element \n");
  scanf("%d",&ele);
  r=(r+1)%MAX;
  q[r]=ele;
  count++;
  } 
  else
   printf("Overflow\n");

 }
void delete()
{
 int ele;
 if(count==0)
  printf("Queue Underflow \n");
 else
 {
  ele=q[f];
  f=(f+1)%MAX;
  count--;
  }
 }
 void display()
 {
 if(f==-1)
   printf("Queue is Empty \n");
 else
 {
   int i=f;
   printf("The elements are: \n");
   if(f<=r)
   {
    while(i<=r)
      printf(" %d \t ",q[i++]);
    }
   else{
   while(i<=MAX-1)
          printf("%d \t",q[i++]);
   i=0;
   while(i<=r)
      printf(" %d \t",q[i++]);
      }
 } 
}
   
  /*int i,n;
  if(count==0)
   printf("Queue is empty\n");
  else
   for(i=f;i<=r;i++)
   {
    //i=i+1%MAX;
    printf("%d",q[i]);
    printf("\t");
    }
    printf("\n");*/
