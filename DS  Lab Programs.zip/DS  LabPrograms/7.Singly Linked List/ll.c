#include<stdio.h>
#include<stdlib.h>
int count=0;
 struct node
{
 char USN[10],Name[10],Branch[4];
 int phno,sem;
 struct node *link;
 } node;
 typedef struct node *Node;
Node start=NULL,temp,temp1;
void insbeg()
{
 temp=(struct node*)malloc(sizeof(struct node));
 printf("Enter USN,Name,Branch,sem,phno\n");
 scanf("%s%s%s%d%d",temp->USN,temp->Name,temp->Branch,&temp->sem,&temp->phno);
 temp->link=start;
 start=temp;
 count++;
 printf("Inserted\n");
}
void insend()
{
 temp1=(struct node*)malloc(sizeof(struct node));
 printf("Enter USN,Name,Branch,sem,phno\n");
 scanf("%s%s%s%d%d",temp1->USN,temp1->Name,temp1->Branch,&temp1->sem,&temp1->phno);
 temp=start;
 while(temp->link!=NULL)
  temp=temp->link;
 temp->link=temp1;
 temp1->link=NULL;
 count++;
 printf("Inserted\n");
}
void delbeg()
{
 temp=start;
 start=start->link;
 free(temp);
 count--;
}
void delend()
{
 temp=start;temp1=start->link;
 while(temp1->link!=NULL)
 {
  temp=temp->link;
  temp1=temp1->link;
 }
 temp->link=NULL;
 free(temp1);
 count--;
}
void create()
{
 int i,n;
 printf("Enter no of elements \n");
 scanf("%d",&n);
 for(i=1;i<=n;i++)
 {
  printf("Enter the details of student %d\n",i);
  insbeg();
 }
}
void display()
{
 int i=1;
 printf("No of nodes = %d \n",count);
 printf("The linked list is \n");
 temp=start;
 while(temp!=NULL)
 {
  printf("Student %d\n",i);
  printf("%s\n%s\n%s\n%d\n%d\n",temp->USN,temp->Name,temp->Branch,temp->sem,temp->phno);
  temp=temp->link;
  i++;
  }
 }
void main()
{
 int op;
 printf("Enter\n1.Create\n2.Display\n3.Insert at end\n4.Delete at end\n5.Insert at front\n6.Delete at front\n7.Exit\n");
 while(1)
 {
  printf("Enter your option\n");
  scanf("%d",&op);
  switch(op)
  {
   case 1:create();break;
   case 2:display();break;
   case 3:insend();break;
   case 4:delend();break;
   case 5:insbeg();break;
   case 6:delbeg();break;
   case 7:exit(0);break;
   default: printf("Invalid Option \n");break;
  }
 }
}

