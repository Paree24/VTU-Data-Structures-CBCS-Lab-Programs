#include<stdio.h>
#include<stdlib.h>
struct emp
{
 int SSN,sal;
 char name[15],dept[15],design[15];
 int phno;
 struct emp *prev,*next;
 };
 typedef struct emp *NODE;
 NODE first=NULL,temp,last=NULL,new,temp1;
 int count=0;
 void create()
 {
  int n,i;
  printf("\nEnter the number of nodes\t");
  scanf("%d",&n);
  for(i=0;i<n;i++)
 {
   new=(struct emp*)malloc(sizeof(struct emp));
   printf("\nEnter employee details(SSN,Name,Dept,Designation,Sal,Ph.)\n");
   scanf("%d %s %s  %s %d %d",&new->SSN,new->name,new->dept,new->design,&new->sal,&new->phno);
   if(first==NULL)
   {
    first=new;last=new;
    new->prev=new->next=NULL;
    count++;
    }
    else
   {
     temp=first;
     while(temp->next!=NULL)
      temp=temp->next;
     temp->next=new;
     new->prev=temp;
     new->next=NULL;
     last=new;
     count++;
    }
   }
  }
  void insend()
  {
   new=(struct emp*)malloc(sizeof(struct emp));
   printf("\nEnter employee details\n");
   scanf("%d %s %s  %s %d %d",&new->SSN,new->name,new->dept,new->design,&new->sal,&new->phno);
     temp=first;
     while(temp->next!=NULL)
      temp=temp->next;
     temp->next=new;
     new->prev=temp;
     new->next=NULL;
     last=new;
     count++;
   }
  void insbeg()
  {
   new=(struct emp*)malloc(sizeof(struct emp));
   printf("\nEnter employee details\n");
   scanf("%d %s %s  %s %d %d",&new->SSN,new->name,new->dept,new->design,&new->sal,&new->phno);
   new->prev=NULL;
   new->next=first;
   first->prev=new;
   first=new;
   count++;
   }
  void delbeg()
  {
   temp=first;
   first=first->next;
   first->prev=NULL;
   free(temp);
   count--;
  }
  void delend()
  {
   temp=last;
   last=last->prev;
   last->next=NULL;
   free(temp);count--;
  }

 void display()
 {
  temp=first;
  printf("\nNo of nodes = %d \n",count);

  printf("Employee details\n");
  while(temp!=NULL)
  {

   printf(" \t%d\t%s\t%s\t%s\t%d\t%d\n",temp->SSN,temp->name,temp->dept,temp->design,temp->sal,temp->phno);
   temp=temp->next;
   }
  }
 void deq()
 {
  printf("\nDemostration of Double ended queue\n");
  display();
  insend();
  printf("After end insertion\n");
  display();
  delbeg();
  printf("After front deletion\n");
  display();
  insbeg();
  printf("After front insertion\n");
  display();
  delend();
  printf("After end deletion\n");
  display();
 }
void main()
 {
    int op;
    printf("Enter 1.Create\t2.Display\t3.Insert end\t4.Delete end\t5.Insert front\t6.Delete\t7.Dequeue\t8.Exit\n");
 while(1)
 {
  printf("Enter your option\n");
  scanf("%d",&op);
  switch(op)
  {
   case 1:create();break;
   case 2:display();break;
   case 3:insend();break;
   case 4:delend();break;
   case 5:insbeg();break;
   case 6:delbeg();break;
   case 7:deq();break;
   case 8:printf("\n ***End of Program*** \n");exit(0);
   default: printf("\nInvalid Option \n");break;
  }
 }
}

