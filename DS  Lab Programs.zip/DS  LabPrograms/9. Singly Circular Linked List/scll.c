#include<stdio.h>
#include<stdlib.h>
#include<math.h>
struct Node
{
 int coeff, xp,yp,zp;
 struct Node *next;
 };
typedef struct Node *NODE;
NODE create()
{
 NODE head,new,p;
 head=(struct Node*)malloc(sizeof(struct Node));
 head->coeff=0;
 head->next=head;
 p=head;
  while(1)
 {
  new=(struct Node*)malloc(sizeof(struct Node));
  printf("\tEnter the Co-efficient\n");
  scanf("%d",&new->coeff);
  if(new->coeff==0)
   break;
  printf("Enter powers of x,y,z \n");
  scanf("%d%d%d",&new->xp,&new->yp,&new->zp);
  new->next=head;
  p->next=new;
  p=new;
 }
  return head;
  }
void eval(NODE head)
{
 int x,y,z,sum=0;
 NODE p;
 printf("\tEnter x,y,z value\n");
 scanf("%d%d%d",&x,&y,&z);
 p=head->next;
 while(p!=head)
 {
  sum=sum+p->coeff*pow(x,p->xp)*pow(y,p->yp)*pow(z,p->zp);
  p=p->next;
  }
 printf("\tEvaluation of polynomial is %d\n",sum);
 }
 NODE attach(NODE polysum,int coeff,int xp,int yp,int zp,NODE r)
{
 NODE new;
 new=(struct Node*)malloc(sizeof(struct Node));
 new->coeff=coeff;
 new->xp=xp;
 new->yp=yp;
 new->zp=zp;
 r->next=new;
 new->next=polysum;
 r=new;
 return r;
}
NODE add(NODE poly1,NODE poly2)
{
 NODE polysum,p,q,r;
 polysum=(struct Node *)malloc(sizeof(struct Node));
 polysum->coeff=0;
 polysum->next=polysum;
 p=poly1->next;
 r=polysum;
 while(p!=poly1)
 {
  q=poly2->next;
  while(q!=poly2)
  {
   if(p->xp==q->xp&&p->yp==q->yp&&p->zp==q->zp&&p->coeff!=0&&q->coeff!=0)
   {
     r=attach(polysum,p->coeff+q->coeff,p->xp,p->yp,p->zp,r);
     p->coeff=q->coeff=0;
    }
  q=q->next;
  }
  p=p->next;
     }
  p=poly1->next;
  while(p!=poly1)
  {
   if(p->coeff!=0)
   {
    r=attach(polysum,p->coeff,p->xp,p->yp,p->zp,r);
    }
   p=p->next;

  }
  q=poly2->next;
  while(q!=poly2)
  {
   if(q->coeff!=0)
   {
    r=attach(polysum,q->coeff,q->xp,q->yp,q->zp,r);
    }
   q=q->next;
   }
   return polysum;
   }
 void main()
 {
  NODE poly1,poly2,polysum,p,poly;
  int op;
  printf("\t1.Create & Evaluate \t 2.Add\t3.Exit\n");
  while(1)
  {
   printf("\tEnter Option\n");
   scanf("%d",&op);
   switch(op)
   {
    case 1: poly=create();
            eval(poly);
            break;
    case 2:printf("\tFirst Polynomial=\n");
           poly1=create();
           printf("\tSecond Polynomial=\n");
           poly2=create();
           polysum=add(poly1,poly2);
           p=polysum->next;
           while(p!=polysum)
           {
            printf("\t%dx^%d y^%d z^%d\n",p->coeff,p->xp,p->yp,p->zp);
            p=p->next;
           }
           break;
    case 3:exit(0);
    }
   }
  }


